package com.example.pro5

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import okhttp3.Headers
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get the button and image view from XML
        val button: Button = findViewById(R.id.pokemonButton)
        val imageView: ImageView = findViewById(R.id.pokemon_view)

        // Set up click listener
        button.setOnClickListener {
            fetchPokemonImage(imageView)
        }
    }

    private fun fetchPokemonImage(imageView: ImageView) {
        val client = AsyncHttpClient()

        // Random Pokémon ID between 1 and 898
        val randomId = Random.nextInt(1, 899)
        val url = "https://pokeapi.co/api/v2/pokemon/$randomId"

        client.get(url, object : JsonHttpResponseHandler() {

            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                try {
                    // Extract sprite URL from JSON
                    val spriteUrl = json.jsonObject
                        .getJSONObject("sprites")
                        .getString("front_default")

                    Log.d("PokemonSpriteURL", spriteUrl)

                    // Load image into ImageView with Glide
                    Glide.with(this@MainActivity)
                        .load(spriteUrl)
                        .fitCenter()
                        .into(imageView)

                } catch (e: Exception) {
                    Log.e("JSONError", "Failed to parse JSON", e)
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                errorResponse: String,
                throwable: Throwable?
            ) {
                Log.e("PokemonError", "Failed to fetch Pokémon: $errorResponse", throwable)
            }
        })
    }
}
